<?php
$db_config = [
  'server'   => 'localhost',
  'login'    => '72707943',
  'password' => 'D7B764aS',
  'database' => 'stud_72707943',
];