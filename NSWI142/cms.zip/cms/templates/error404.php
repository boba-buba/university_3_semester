<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <title>Articles</title>
    <link rel='stylesheet' type='text/css' href='../style.css'>

</head>
<body>
    <main>
        <h1>404</h1>
    </main>
</body>
</html>