<?php

class error404
{
	function default()
	{
		include __DIR__. '/../templates/error404.php';
	}

}